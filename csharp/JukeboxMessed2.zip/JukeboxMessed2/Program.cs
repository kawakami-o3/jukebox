﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JukeboxMessed {
	public class Program {
		public static void Main(string[] args) {
			/// ジュークボックスエミュレータ
			/// 仕様
			/// - ジュークボックスは複数の楽曲データを所持している
			/// - 一つの楽曲データには、アーティスト名、アルバム名、タイトル、曲の長さが含まれている
			/// - ユーザが入力するコマンドに応じて以下の操作を行う
			///   1. 曲の再生
			///   2. プレイリストの自動生成
			///   3. プレイリストの曲飛ばし
			///   4. プレイリストへ曲を追加
			///   5. プレイリストから曲を削除
			///   6. 曲飛ばし方法の変更(順送り、ランダム)
			///   7. 現在の曲情報の表示
			///   8. 楽曲データ一覧の表示
			///   9. アルバム情報の表示

			var cd1 = new CD("SiM", "EViLS");
			cd1.Add("Blah Blah Blah", 8);
			cd1.Add("Same Sky", 3);
			cd1.Add("faith", 9);

			var cd2 = new CD("Fact", "burundanga");
			cd2.Add("FOSS", 3);
			cd2.Add("1000 miles", 13);
			cd2.Add("pink rolex", 5);

			var jukebox = new Jukebox(cd1, cd2);

			//jukebox.ActivateAuto(new Commands.Shuffle(3));
			//jukebox.ActivateAuto(new Commands.Info());
			//jukebox.ActivateAuto(new Commands.PlayList());
			//jukebox.ActivateAuto(new Commands.Selector(Selector.Random));
			//jukebox.ActivateAuto(new Commands.Play());
			//jukebox.ActivateAuto(new Commands.Next());
			//jukebox.ActivateAuto(new Commands.Play());


			jukebox.ActivateAuto(new Commands.List());
			jukebox.ActivateAuto(new Commands.Add(1));
			jukebox.ActivateAuto(new Commands.Add(3));
			jukebox.ActivateAuto(new Commands.PlayList());
			jukebox.ActivateAuto(new Commands.Remove(0));
			jukebox.ActivateAuto(new Commands.PlayList());
			jukebox.ActivateAuto(new Commands.CD());
			jukebox.ActivateAuto(new Commands.List("burundanga"));

			Console.ReadKey();
		}
	}
}

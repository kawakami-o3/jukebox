﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace JukeboxMessed {
	public class SongSelector {
		public SongSelector(string name, Func<List<Song>, int> selector) {
			this.Name = name;
			this.selector = selector;
		}

		public string Name { get; private set; }

		private readonly Func<List<Song>, int> selector;

		public void Select(List<Song> playList) {
			if (playList.Count != 0) {
				int nextIndex = 0;

				if (2 <= playList.Count) {
					nextIndex = this.selector(playList);
					playList[0] = playList[nextIndex];
				}

				playList.RemoveAt(nextIndex);
			}
		}

		public override string ToString() {
			return this.Name;
		}

		static SongSelector() {
			SongSelector.Normal = new SongSelector("Normal", list => 1);
			SongSelector.Revers = new SongSelector("Revers", list => list.Count - 1);
			SongSelector.Random = new SongSelector("Random", list => Enumerable.Range(1, list.Count - 1).Random().First());
		}

		public static SongSelector Normal { get; private set; }

		public static SongSelector Revers { get; private set; }

		public static SongSelector Random { get; private set; }
	}
}

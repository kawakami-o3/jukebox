﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace JukeboxMessed {
	public class CDPlayer {
		public CDPlayer() {
			this.PlayList = new List<Song>();
		}

		public List<Song> PlayList { get; private set; }

		public SongSelector Selector { get; set; }

		public Song CurrentSong {
			get {
				return this.PlayList.First();
			}
		}

		public void Play() {
			Console.WriteLine("{0}:{1}", this.CurrentSong.Name, new String('♪', this.CurrentSong.Length));
		}

		public void Next() {
			this.Selector.Select(this.PlayList);
		}
	}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JukeboxMessed {
	public static class EnumerableUtility {
		public static void ForEach<T>(this IEnumerable<T> source, Action<T> action) {
			foreach (var item in source) {
				action(item);
			}
		}

		public static void ForEach<T>(this IEnumerable<T> source, Action<T, int> action) {
			int i = -1;
			foreach (var item in source) {
				action(item, ++i);
			}
		}

		public static IEnumerable<T> Random<T>(this IEnumerable<T> source) {
			return source.OrderBy(item => Guid.NewGuid());
		}
	}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace JukeboxMessed.Commands {
	public abstract class JukeBoxCommand {
		public abstract void Execute(Jukebox jukebox);

		protected virtual string ArgString {
			get {
				return String.Empty;
			}
		}

		public override string ToString() {
			return String.Format("{0} {1}", this.GetType().Name, this.ArgString).Trim();
		}
	}

	public class Play : JukeBoxCommand {
		public override void Execute(Jukebox jukebox) {
			jukebox.CDPlayer.Play();
		}
	}

	public class Next : JukeBoxCommand {
		public override void Execute(Jukebox jukebox) {
			jukebox.CDPlayer.Next();
		}
	}

	public class Selector : JukeBoxCommand {
		public Selector(SongSelector selector) {
			this.selector = selector;
		}

		private readonly SongSelector selector;

		protected override string ArgString {
			get {
				return this.selector.ToString();
			}
		}

		public override void Execute(Jukebox jukebox) {
			jukebox.CDPlayer.Selector = this.selector;
		}
	}

	public class Shuffle : JukeBoxCommand {
		public Shuffle(int count) {
			this.count = count;
		}

		private readonly int count;

		protected override string ArgString {
			get {
				return this.count.ToString();
			}
		}

		public override void Execute(Jukebox jukebox) {
			jukebox.CDPlayer.PlayList.Clear();
			jukebox.CDPlayer.PlayList.AddRange(jukebox.Songs.Random().Take(this.count));
		}
	}

	public class Info : JukeBoxCommand {
		public override void Execute(Jukebox jukebox) {
			Console.WriteLine(jukebox.CDPlayer.CurrentSong);
		}
	}

	public class PlayList : JukeBoxCommand {
		public override void Execute(Jukebox jukebox) {
			jukebox.CDPlayer.PlayList.ForEach((song, i) => Console.WriteLine("No. {0} {1}", ++i, song));
		}
	}

	public class List : JukeBoxCommand {
		public List(params string[] cdNames) {
			this.cdNames = cdNames;
		}

		private readonly string[] cdNames;

		protected override string ArgString {
			get {
				return String.Join(", ", this.cdNames);
			}
		}

		public override void Execute(Jukebox jukebox) {
			if (cdNames.Length == 0) {
				jukebox.Songs.ForEach((song, i) => Console.WriteLine("{0}: {1}", i, song));
			} else {
				foreach (string cdName in cdNames) {
					jukebox.CDs.Where(cd => cd.Name == cdName).ForEach((song, i) => Console.WriteLine("{0}:{1}", i, song));
				}
			}
		}
	}

	public class Add : JukeBoxCommand {
		public Add(params int[] songIndices) {
			this.songIndices = songIndices;
		}

		private readonly int[] songIndices;

		protected override string ArgString {
			get {
				return String.Join(", ", this.songIndices);
			}
		}

		public override void Execute(Jukebox jukebox) {
			foreach (int index in this.songIndices) {
				jukebox.CDPlayer.PlayList.Add(jukebox.Songs[index]);
			}
		}
	}

	public class Remove : JukeBoxCommand {
		public Remove(params int[] playListSongIndices) {
			this.playListSongIndices = playListSongIndices;
		}

		private readonly int[] playListSongIndices;

		protected override string ArgString {
			get {
				return String.Join(", ", this.playListSongIndices);
			}
		}

		public override void Execute(Jukebox jukebox) {
			foreach (int index in this.playListSongIndices.OrderByDescending(idx => idx)) {
				jukebox.CDPlayer.PlayList.RemoveAt(index);
			}
		}
	}

	public class CD : JukeBoxCommand {
		public override void Execute(Jukebox jukebox) {
			Console.WriteLine("現在のアルバム:{0}", jukebox.CDPlayer.CurrentSong.CD.Name);
		}
	}
}
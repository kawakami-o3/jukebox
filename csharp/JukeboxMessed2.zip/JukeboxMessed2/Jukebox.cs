﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JukeboxMessed.Commands;

namespace JukeboxMessed {
	public class Jukebox {
		public Jukebox(params CD[] cds) {
			this.CDs = cds.ToList();
			this.CDPlayer = new CDPlayer();
		}

		public CDPlayer CDPlayer { get; private set; }

		public IReadOnlyList<CD> CDs { get; private set; }

		public IReadOnlyList<Song> Songs {
			get {
				return this.CDs.SelectMany(cd => cd.Songs).ToList();
			}
		}

		public void ActivateAuto(params JukeBoxCommand[] commands) {
			foreach (var cmd in commands) {
				Console.WriteLine("コマンド> {0}", cmd);
				cmd.Execute(this);
			}
		}
	}
}

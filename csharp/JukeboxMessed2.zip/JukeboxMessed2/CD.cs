﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JukeboxMessed {
	public class CD {
		public CD(string artist, string name) {
			this.Artist = artist;

			this.Name = name;
		}

		private readonly List<Song> songs = new List<Song>();

		public string Artist { get; private set; }

		public string Name { get; private set; }

		public IReadOnlyList<Song> Songs {
			get {
				return this.songs;
			}
		}

		public void Add(string name, int length) {
			var song = new Song(name, length, this);
			this.songs.Add(song);
		}
	}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace JukeboxMessed {
	public class Song {
		public Song(string name, int length, CD cd) {
			this.Name = name;
			this.Length = length;
			this.CD = cd;
		}

		public string Name { get; private set; }

		public int Length { get; private set; }

		public CD CD { get; private set; }

		public override string ToString() {
			return String.Format("アーティスト:{0}, アルバム:{1}, タイトル:{2}, 長さ:{3}", this.CD.Artist, this.CD.Name, this.Name, this.Length);
		}
	}
}

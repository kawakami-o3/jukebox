﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JukeboxMessed {
	public class JukeboxMessed {
		/// <summary>
		/// ジュークボックスエミュレータ
		/// 仕様
		/// - ジュークボックスは複数の楽曲データを所持している
		/// - 一つの楽曲データには、アーティスト名、アルバム名、タイトル、曲の長さが含まれている
		/// - ユーザが入力するコマンドに応じて以下の操作を行う
		///   1. 曲の再生
		///   2. プレイリストの自動生成
		///   3. プレイリストの曲飛ばし
		///   4. プレイリストへ曲を追加
		///   5. プレイリストから曲を削除
		///   6. 曲飛ばし方法の変更(順送り、ランダム)
		///   7. 現在の曲情報の表示
		///   8. 楽曲データ一覧の表示
		///   9. アルバム情報の表示
		/// </summary>
		/// <param name="artists"></param>
		/// <param name="cdNames"></param>
		/// <param name="songNames"></param>
		/// <param name="songLengthList"></param>
		public JukeboxMessed(List<string> artists, List<string> cdNames, List<string> songNames, List<int> songLengthList) {
			this.artists = new List<string>(artists);
			this.cdNames = new List<string>(cdNames);
			this.songNames = new List<string>(songNames);
			this.songLengthList = new List<int>(songLengthList);

			playlist = new List<int>();
			selector = "normal";
			rnd = new Random();
		}

		private Random rnd;

		private List<string> artists;
	
		private List<string> cdNames;
		
		private List<string> songNames;
		
		private List<int> songLengthList;

		private List<int> playlist;

		private string selector;

		public void ActivateAuto(params string[] commands) {
			foreach (string cmd in commands) {
				Console.WriteLine("コマンド> " + cmd);
				List<string> words = new List<string>(cmd.Split(' '));
				switch (words[0]) {
					case "play":
						Console.Write(songNames[playlist[0]] + ": ");
						for (int i = 0; i < songLengthList[playlist[0]]; i++) {
							Console.Write("♪");
						}
						Console.WriteLine();
						break;
					case "next":
						switch (selector) {
							case "reverse":
								playlist[0] = playlist[playlist.Count - 1];
								playlist.RemoveAt(playlist.Count - 1);
								break;
							case "random":
								int i = 1 + rnd.Next(playlist.Count - 1);
								if (i != 1) {
									int tmp_b = playlist[1];
									playlist[1] = playlist[i];
									playlist[i] = tmp_b;
								}
								playlist.RemoveAt(0);
								break;
							case "normal":
							default:
								playlist.RemoveAt(0);
								break;
						}
						break;
					case "selector":
						selector = words[1];
						break;
					case "shuffle":
						playlist = new List<int>();
						int size = words.Count == 1 ? songNames.Count : int.Parse(words[1]);
						for (int i = 0; i < size; i++) {
							playlist.Add(rnd.Next(songNames.Count));
						}
						break;
					case "info":
						Console.Write("アーティスト : " + artists[playlist[0]]);
						Console.Write("アルバム : " + cdNames[playlist[0]]);
						Console.Write("タイトル : " + songNames[playlist[0]]);
						Console.Write("長さ : " + songLengthList[playlist[0]]);
						Console.WriteLine();
						break;
					case "playlist":
						for (int i = 0; i < playlist.Count; i++) {
							Console.Write("No. " + playlist[i] + ": ");
							Console.Write("アーティスト=" + artists[playlist[i]] + ", ");
							Console.Write("アルバム=" + cdNames[playlist[i]] + ", ");
							Console.Write("タイトル=" + songNames[playlist[i]] + ", ");
							Console.Write("長さ=" + songLengthList[playlist[i]]);
						Console.WriteLine();
						}
						break;
					case "list":
						if (words.Count > 1) {
							foreach (string target in words.GetRange(1, words.Count - 1)) {
								for (int i = 0; i < songNames.Count; i++) {
									if (cdNames[i] == target) {
										Console.WriteLine(i + ": " + songNames[i]);
									}
								}
							}
						} else {
							for (int i = 0; i < songNames.Count; i++) {
								Console.WriteLine(i + ": " + songNames[i]);
							}
						}
						break;
					case "add":
						playlist.Add(int.Parse(words[1]));
						break;
					case "remove":
						playlist.RemoveAt(int.Parse(words[1]));
						break;
					case "cd":
						Console.WriteLine("現在のアルバム: " + cdNames[playlist[0]]);
						break;
					default:
						Console.WriteLine("コマンド \"" + cmd + "\" はサポートされていません。");
						break;
				}
			}
		}

		public static void Main(string[] args) {
			var artists = new List<string>();
			var cdNames = new List<string>();
			var songNames = new List<string>();
			var songLengthList = new List<int>();

			artists.Add("SiM");
			cdNames.Add("EViLS");
			songNames.Add("Blah Blah Blah");
			songLengthList.Add(8);

			artists.Add("SiM");
			cdNames.Add("EViLS");
			songNames.Add("Same Sky");
			songLengthList.Add(3);


			artists.Add("SiM");
			cdNames.Add("EViLS");
			songNames.Add("faith");
			songLengthList.Add(9);

			artists.Add("Fact");
			cdNames.Add("burundanga");
			songNames.Add("FOSS");
			songLengthList.Add(3);

			artists.Add("Fact");
			cdNames.Add("burundanga");
			songNames.Add("1000 miles");
			songLengthList.Add(13);

			artists.Add("Fact");
			cdNames.Add("burundanga");
			songNames.Add("pink rolex");
			songLengthList.Add(5);

			new JukeboxMessed(artists, cdNames, songNames, songLengthList).ActivateAuto("shuffle 3", "info", "playlist", "selector random", "play", "next", "play");
			//new JukeboxMessed(artists, cdNames, songNames, songLengthList).ActivateAuto("list", "add 1", "add 3", "remove 0", "playlist", "cd", "list burundanga");
			Console.ReadKey();
		}
	}
}
